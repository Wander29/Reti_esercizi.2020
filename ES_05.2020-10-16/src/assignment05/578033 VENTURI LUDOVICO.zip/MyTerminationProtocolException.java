package assignment05;

/**
 * @author      LUDOVICO VENTURI 578033
 * @version     1.0
 * @date        2020-10-22
 */

public class MyTerminationProtocolException extends RuntimeException {
    public MyTerminationProtocolException() { super(); }

    public MyTerminationProtocolException(String s) { super(s); }
}
