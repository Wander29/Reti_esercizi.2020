package protocol.exceptions;

public class IllegalProtocolMessageException extends Exception {

    public IllegalProtocolMessageException() { super(); }
    public IllegalProtocolMessageException(String s) { super(s); }

}
