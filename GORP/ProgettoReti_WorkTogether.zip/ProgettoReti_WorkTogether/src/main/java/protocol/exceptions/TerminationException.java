package protocol.exceptions;

public class TerminationException extends Exception {
    public TerminationException(String s)   { super(s); }
    public TerminationException()           { super();  }
}

