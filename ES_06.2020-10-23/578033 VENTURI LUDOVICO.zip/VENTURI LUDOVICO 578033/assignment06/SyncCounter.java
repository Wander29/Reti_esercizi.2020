package assignment06;

public class SyncCounter {
    private int cnt;


}
