package assignment04;

/**
 * @author		LUDOVICO VENTURI 578033
 * @date		2020/10/23
 * @versione	1.1
 */

public abstract class StrutturaLaboratorio {
    protected final int LAB_SIZE = 20;
}
